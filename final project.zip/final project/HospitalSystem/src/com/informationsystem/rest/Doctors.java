/*Author : Megha Sogani*/

package com.informationsystem.rest;


import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;



public class Doctors {
	private String id;
	private String name;
	private String patientsId;
	
	// Must have no-argument constructor
	
	    public Doctors() {

	    }

	  public Doctors (String id, String name, String patientsId){
		    super();
		    this.id = id;
	    this.name = name;
	    this.patientsId = patientsId;
	  }
	  public String getId() {
		return id;
	  }
	  public void setId(String id) {
		this.id = id;
	  }
	  public String getName() {
		return name;
	  }
	  public void setName(String name) {
		this.name = name;
	  }
	  public String getPatientId() {
		return patientsId;
	  }
	  public void setPatientId(String patientsId) {
		this.patientsId = patientsId;
	  }
}
