/*Author : Megha Sogani*/

package com.informationsystem.rest;
import javax.ws.rs.PathParam;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;


@Path("/doctor")
public class DoctorResource {
	 private static final String COMMA_DELIMITER = ",";
	 private static final String NEW_LINE_SEPARATOR = "\n";
	private static final String FILE_HEADER = "id,name,PatientId";
	private String fileName = "G:/webservice/doctor.csv";
	private String patientsfileName = "G:/webservice/patient.csv";
	
	 @POST
	  public String createDoctor(@FormParam("id") String id,@FormParam("name") String name,@FormParam("patientId") String patientId) {
		 
		 System.out.println(id);
		 Doctors doctors = new Doctors(id, name, patientId);
		 List<Doctors> doctorsList = new ArrayList<Doctors>();
		 doctorsList.add(doctors);
	
	
		 FileWriter file = null;

		 try {
			 boolean alreadyExists = new File(fileName).exists();
			 
			
			 	file= new FileWriter(fileName,true);
			 	 if(!alreadyExists) { 
			 		//Write the CSV file header
						file.append(FILE_HEADER.toString());
						
						//Add a new line separator after the header
						file.append(NEW_LINE_SEPARATOR);
				 }
			
				
				//Write a new student object list to the CSV file
				for (Doctors doctor : doctorsList) {
					file.append(doctor.getId());
					
					file.append(COMMA_DELIMITER);
					file.append(doctor.getName());
					file.append(COMMA_DELIMITER);
					file.append(doctor.getPatientId());
					file.append(NEW_LINE_SEPARATOR);
					
				}
				file.flush();
				file.close();
				
				
				 return "Doctors List successfully created";
				
			} catch (Exception e) {
				 return e.getMessage();
				
			} 

	
	 }

	 @DELETE 
	 @Path("{id}")
	  public String deleteDoctor(@PathParam("id") String id) {
		 System.out.print(id);
		 BufferedReader reader = null;
	     
	        try {
	        	
	       
	        	//Create a new list of student to be filled by CSV file data 
	        	List<Doctors> doctorsList = new ArrayList<Doctors>();
	        	
	            String line = "";
	            
	            //Create the file reader
	            reader = new BufferedReader(new FileReader(fileName));
	            
	            //Read the CSV file header to skip it
	            reader.readLine();
	            
	            //Read the file line by line starting from the second line
	            while ((line = reader.readLine()) != null) {
	                //Get all tokens available in line
	                String[] array_tokens = line.split(COMMA_DELIMITER);
	                if (array_tokens.length > 0) {
	                	//Create a new student object and fill his  data
						Doctors doctors = new Doctors(array_tokens[0], array_tokens[1], array_tokens[2]);
						System.out.print(array_tokens[0]);
						System.out.print(id);
						if(!array_tokens[0].equals(id)){
						
						doctorsList.add(doctors);
						}
					}
	            }
	            
	            
	            FileWriter file = null;
	         	file= new FileWriter(fileName);
			 
						file.append(FILE_HEADER.toString());
						
						//Add a new line separator after the header
						file.append(NEW_LINE_SEPARATOR);
				
			
				
				//Write a new student object list to the CSV file
				for (Doctors doc : doctorsList) {
					file.append(doc.getId());
					
					file.append(COMMA_DELIMITER);
					file.append(doc.getName());
					file.append(COMMA_DELIMITER);
					file.append(doc.getPatientId());
					file.append(NEW_LINE_SEPARATOR);
				
				}
				file.flush();
				file.close();
				
	            return "Sucessfully Deleted";
	            
				//return docData;
	        } 
	        catch (Exception e) {
	        	return e.getMessage();
	        } 
		 
		
	 }
	 
	 @PUT
	  public String updateDoctor(@FormParam("id") String id,@FormParam("name") String name) {
		 BufferedReader fileReader = null;
	     
	        try {
	        	
	       
	        	//Create a new list of student to be filled by CSV file data 
	        	List<Doctors> doctorsList = new ArrayList<Doctors>();
	        	
	            String line = "";
	            
	            //Create the file reader
	            fileReader = new BufferedReader(new FileReader(fileName));
	            
	            //Read the CSV file header to skip it
	            fileReader.readLine();
	            
	            //Read the file line by line starting from the second line
	            while ((line = fileReader.readLine()) != null) {
	                //Get all tokens available in line
	                String[] tokens = line.split(COMMA_DELIMITER);
	                if (tokens.length > 0) {
	                	//Create a new student object and fill his  data
						Doctors docient = new Doctors(tokens[0], tokens[1], tokens[2]);
						if(tokens[0].equals(id)){
							System.out.print(tokens[0]);
						docient.setName(name);
						}
						doctorsList.add(docient);
					}
	            }
	            
	            //Print the new student list
	            String output = "sucess";
	            FileWriter fileWriter = null;
	         	fileWriter= new FileWriter(fileName);
			 
						fileWriter.append(FILE_HEADER.toString());
						
						//Add a new line separator after the header
						fileWriter.append(NEW_LINE_SEPARATOR);
				
			
				
				//Write a new student object list to the CSV file
				for (Doctors doctor : doctorsList) {
					fileWriter.append(doctor.getId());
					
					fileWriter.append(COMMA_DELIMITER);
					fileWriter.append(doctor.getName());
					fileWriter.append(COMMA_DELIMITER);
					fileWriter.append(doctor.getPatientId());
					fileWriter.append(NEW_LINE_SEPARATOR);
				
				}
				fileWriter.flush();
				fileWriter.close();
				
	            return output;
	            
				//return docData;
	        } 
	        catch (Exception e) {
	        	return e.getMessage();
	        } 
		 
	 }
	 
	 @GET
	 @Produces(MediaType.APPLICATION_XML)
	  public DOMSource getDoctor() {
	
		 System.out.print("asda");
		 
		 BufferedReader reader = null;
		 BufferedReader docfileReader = null;
		 DocumentBuilderFactory doctorFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder doctorBuilder = null;
			try {
				doctorBuilder = doctorFactory.newDocumentBuilder();
			} catch (ParserConfigurationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	     
	        try {
	        	
	        	
	        	List<Patients> patientsList = new ArrayList<Patients>();
	        	List<Doctors> doctorsList = new ArrayList<Doctors>();
	            String line = "";
	            
	   
	            reader = new BufferedReader(new FileReader(patientsfileName));
	            docfileReader = new BufferedReader(new FileReader(fileName));
	       
	            reader.readLine();
	            docfileReader.readLine();
	            
	    	
				
				
	            //Read the file line by line starting from the second line
	            while ((line = reader.readLine()) != null) {
	                //Get all tokens available in line
	                String[] array_tokens = line.split(COMMA_DELIMITER);
	                if (array_tokens.length > 0) {
	                	//Create a new student object and fill his  data
						Patients pat = new Patients(array_tokens[0], array_tokens[1], array_tokens[2]);
						patientsList.add(pat);
					}
	            }
	            
	        	// root elements
				Document document = doctorBuilder.newDocument();
				Element root = document.createElement("doctors");
				document.appendChild(root);
	            while ((line = docfileReader.readLine()) != null) {
	             
	                String[] array_tokens = line.split(COMMA_DELIMITER);
	                if (array_tokens.length > 0) {
	                
	        			Element doctors = document.createElement("doctors");
	        			root.appendChild(doctors);
	        			
	        			Attr attribute = document.createAttribute("id");
	        			attribute.setValue(array_tokens[0]);
	        			doctors.setAttributeNode(attribute);
	        			
	        			Element fname = document.createElement("name");
	        			fname.appendChild(document.createTextNode(array_tokens[1]));
	        			doctors.appendChild(fname);
	        			
	        			for (Patients pat : patientsList) {
	        				String patientid=pat.getId();
	        				String insurance_no=pat.getInsuranceNo();
	        				String full_name=pat.getName();
	    				if(patientid.equals(array_tokens[2])){
	    					Element patients = document.createElement("patient");
	    					doctors.appendChild(patients);
	    					
	    					Attr patientsAttr = document.createAttribute("id");
	    					patientsAttr.setValue(patientid);
	    					patients.setAttributeNode(patientsAttr);
	    					
	    					Element patient_name = document.createElement("name");
	    					patient_name.appendChild(document.createTextNode(full_name));
		        			patients.appendChild(patient_name);
		        			
		        			Element insurance_name = document.createElement("insurancename");
		        			insurance_name.appendChild(document.createTextNode(insurance_no));
		        			patients.appendChild(insurance_name);
		        		
	    					
	    					
	    					
	    				}
	    					
	    				}
	        		
					}
	            }
	            DOMSource src = new DOMSource(document);

		        return src;
	     
	        } 
	        catch (Exception e) {
	        	//return e.getMessage();
	        } 
	        
	        DOMSource source = new DOMSource();
			
	        return  source;
	   
		 
	 }
	 
	 
	 @GET
	 @Path("/plain")
	 @Produces(MediaType.TEXT_PLAIN)
	  public String getTextdDoctor() {
		 String finallist="";
		 System.out.print("asda");
		 
		 BufferedReader reader = null;
		 BufferedReader docfileReader = null;
		 DocumentBuilderFactory doctorFactory = DocumentBuilderFactory.newInstance();
		 DocumentBuilder doctorBuilder = null;
			try {
				doctorBuilder = doctorFactory.newDocumentBuilder();
			} catch (ParserConfigurationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	     
	        try {
	        	
	        	
	        	List<Patients> patientsList = new ArrayList<Patients>();
	        	List<Doctors> doctorsList = new ArrayList<Doctors>();
	            String line = "";
	            
	   
	            reader = new BufferedReader(new FileReader(patientsfileName));
	            docfileReader = new BufferedReader(new FileReader(fileName));
	       
	            reader.readLine();
	            docfileReader.readLine();
	            
	    	
				
				
	            //Read the file line by line starting from the second line
	            while ((line = reader.readLine()) != null) {
	                //Get all tokens available in line
	                String[] array_tokens = line.split(COMMA_DELIMITER);
	                if (array_tokens.length > 0) {
	                	//Create a new student object and fill his  data
						Patients pat = new Patients(array_tokens[0], array_tokens[1], array_tokens[2]);
						patientsList.add(pat);
					}
	            }
	        
	            while ((line = docfileReader.readLine()) != null) {
	             
	                String[] array_tokens = line.split(COMMA_DELIMITER);
	                if (array_tokens.length > 0) {
	                
	        			
	        			
	        			finallist=finallist.concat(array_tokens[0]);
	        			finallist=finallist.concat(array_tokens[1]);
	        			finallist=finallist.concat("=>");
	        			System.out.println(finallist);
	        			
	        			
	        			for (Patients pat : patientsList) {
	        				String patientid=pat.getId();
	        				String insurance_no=pat.getInsuranceNo();
	        				String full_name=pat.getName();
	    				if(patientid.equals(array_tokens[2])){
	    					finallist=finallist.concat(patientid+"-");
		        			finallist=finallist.concat(full_name+"-");
		        			finallist=finallist.concat(insurance_no+"\n");
		        		
	    					
	    					
	    					
	    				}
	    					
	    				}
	        		
					}
	            }
	          

		        return finallist;
	     
	        } 
	        catch (Exception e) {
	        	//return e.getMessage();
	        } 
	        
	       
			
	        return  finallist;
	   
		 
	 }
	 
	 
	 
	  @GET @Path("{id}")
	 @Produces(MediaType.APPLICATION_XML)
	  public DOMSource getDoctorById(@PathParam("id") String id) {
		  String id_Doctor=id;
		 BufferedReader reader = null;
		 BufferedReader docfileReader = null;
		 DocumentBuilderFactory doctorFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder doctorBuilder = null;
			try {
				doctorBuilder = doctorFactory.newDocumentBuilder();
			} catch (ParserConfigurationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	     
	        try {
	        	
	        	
	        	List<Patients> patientsList = new ArrayList<Patients>();
	        	List<Doctors> doctorsList = new ArrayList<Doctors>();
	            String line = "";
	            
	   
	            reader = new BufferedReader(new FileReader(patientsfileName));
	            docfileReader = new BufferedReader(new FileReader(fileName));
	       
	            reader.readLine();
	            docfileReader.readLine();
	            
	    	
				
				
	            //Read the file line by line starting from the second line
	            while ((line = reader.readLine()) != null) {
	                //Get all tokens available in line
	                String[] array_tokens = line.split(COMMA_DELIMITER);
	                if (array_tokens.length > 0) {
	                	//Create a new student object and fill his  data
						Patients pat = new Patients(array_tokens[0], array_tokens[1], array_tokens[2]);
						patientsList.add(pat);
					}
	            }
	            
	        	// root elements
				Document document = doctorBuilder.newDocument();
				Element root = document.createElement("doctors");
				document.appendChild(root);
	            while ((line = docfileReader.readLine()) != null) {
	             
	                String[] array_tokens = line.split(COMMA_DELIMITER);
	                if (array_tokens[0].equals(id_Doctor)) {
	                
	        			Element doctors = document.createElement("doctor");
	        			root.appendChild(doctors);
	        			
	        			Attr attribute = document.createAttribute("id");
	        			attribute.setValue(array_tokens[0]);
	        			doctors.setAttributeNode(attribute);
	        			
	        			Element fname = document.createElement("name");
	        			fname.appendChild(document.createTextNode(array_tokens[1]));
	        			doctors.appendChild(fname);
	        			
	        			for (Patients pat : patientsList) {
	        				String patientid=pat.getId();
	        				String insurance_no=pat.getInsuranceNo();
	        				String full_name=pat.getName();
	    				if(patientid.equals(array_tokens[2])){
	    					Element patients = document.createElement("patient");
	    					doctors.appendChild(patients);
	    					
	    					Attr patientsAttr = document.createAttribute("id");
	    					patientsAttr.setValue(patientid);
	    					patients.setAttributeNode(patientsAttr);
	    					
	    					Element patient_name = document.createElement("name");
	    					patient_name.appendChild(document.createTextNode(full_name));
		        			patients.appendChild(patient_name);
		        			
		        			Element insurance_name = document.createElement("insurancename");
		        			insurance_name.appendChild(document.createTextNode(insurance_no));
		        			patients.appendChild(insurance_name);
		        		
	    					
	    				}
	    					
	    				}
	        		
					}
	            }
	            DOMSource src = new DOMSource(document);

		        return src;
	     
	        } 
	        catch (Exception e) {
	        	//return e.getMessage();
	        } 
	        
	        DOMSource blank = new DOMSource();
			
	        return  blank;
		 
	 }
	  

	  @GET @Path("{id}/plain")
	 @Produces(MediaType.TEXT_PLAIN)
	  public String getDoctorByIdText(@PathParam("id") String id) {
		  String id_Doctor=id;
		  String finallist="";
		 BufferedReader reader = null;
		 BufferedReader docfileReader = null;
		 DocumentBuilderFactory doctorFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder doctorBuilder = null;
			try {
				doctorBuilder = doctorFactory.newDocumentBuilder();
			} catch (ParserConfigurationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	     
	        try {
	        	
	        	
	        	List<Patients> patientsList = new ArrayList<Patients>();
	        	List<Doctors> doctorsList = new ArrayList<Doctors>();
	            String line = "";
	            
	   
	            reader = new BufferedReader(new FileReader(patientsfileName));
	            docfileReader = new BufferedReader(new FileReader(fileName));
	       
	            reader.readLine();
	            docfileReader.readLine();
	            
	    	
				
				
	            //Read the file line by line starting from the second line
	            while ((line = reader.readLine()) != null) {
	                //Get all tokens available in line
	                String[] array_tokens = line.split(COMMA_DELIMITER);
	                if (array_tokens.length > 0) {
	                	//Create a new student object and fill his  data
						Patients pat = new Patients(array_tokens[0], array_tokens[1], array_tokens[2]);
						patientsList.add(pat);
					}
	            }
	           
	            while ((line = docfileReader.readLine()) != null) {
	             
	                String[] array_tokens = line.split(COMMA_DELIMITER);
	                if (array_tokens[0].equals(id_Doctor)) {
	                

	        			finallist=finallist.concat(array_tokens[0]);
	        			finallist=finallist.concat(array_tokens[1]);
	        			finallist=finallist.concat("=>");
	        			
	        			for (Patients pat : patientsList) {
	        				String patientid=pat.getId();
	        				String insurance_no=pat.getInsuranceNo();
	        				String full_name=pat.getName();
	    				if(patientid.equals(array_tokens[2])){
	    				
	    					finallist=finallist.concat(patientid+"-");
		        			finallist=finallist.concat(full_name+"-");
		        			finallist=finallist.concat(insurance_no+"\n");
		        		
	    					
	    				}
	    					
	    				}
	        		
					}
	            }
	           

		        return finallist;
	     
	        } 
	        catch (Exception e) {
	        	//return e.getMessage();
	        } 
	        
	        DOMSource blank = new DOMSource();
			
	        return  finallist;
		 
	 }
	 
	 
	 
	 
	

}
