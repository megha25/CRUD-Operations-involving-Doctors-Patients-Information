/*Author : Megha Sogani*/

package com.informationsystem.rest;


import java.util.ArrayList;

import java.util.List;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlType;


public class Patients 
{
	private String id;
	private String name;
	private String insurance;
	
	public Patients (String id, String name, String insurance)
	{
		super();
		this.id = id;
	    this.name = name;
	    this.insurance = insurance;
	  }
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getInsuranceNo()
	{
		return insurance;
	}
	public void setInsuranceNo(String insurance)
	{
		this.insurance = insurance;
	}
	@Override
	public String toString() {
		return "Student [id=" + id + ", firstName=" + name
				+ ", lastName=" + insurance + "]";
	}
	  
	  
}
