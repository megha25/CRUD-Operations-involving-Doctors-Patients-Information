/*Author : Megha Sogani*/

package com.informationsystem.rest;

import javax.ws.rs.DELETE;

import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.File;
 


@Path("/patient")
public class PatientsResource 
{
	private static final String COMMA_DELIMITER = ",";
	private static final String NEW_LINE_SEPARATOR = "\n";
	private static final String FILE_HEADER = "id,name,insurance";
	private String fileName = "G:/webservice/patient.csv";
	public String patData;
	
	 @POST
	  public String createPatient(@FormParam("id") String id,@FormParam("name") String name,@FormParam("insurance") String insurance) {
	

		 Patients pat = new Patients(id,name,insurance);
		 
		 List<Patients> patientsList = new ArrayList<Patients>();
		 patientsList.add(pat);
		
	
		 FileWriter file = null;

		 try {
			 boolean alreadyExists = new File(fileName).exists();
			 
				
			 	file= new FileWriter(fileName,true);
			 	 if(!alreadyExists) { 
			 		//Write the CSV file header into the file
						file.append(FILE_HEADER.toString());
						
						//Add a new line separator after the header
						file.append(NEW_LINE_SEPARATOR);
				 }
			
				
				//Write a new student object list to the CSV file
				for (Patients patients : patientsList) {
					file.append(patients.getId());
					
					file.append(COMMA_DELIMITER);
					file.append(patients.getName());
					file.append(COMMA_DELIMITER);
					file.append(patients.getInsuranceNo());
					file.append(NEW_LINE_SEPARATOR);
					
				}
				file.flush();
				file.close();
				
				
				 return "Patient list successfully created!!!!";
				
			} catch (Exception e) {
				 return e.getMessage();
				
			} 

		 
	   
	  }
	
	 @GET
	  public String getPatient() {
		 BufferedReader reader = null;
	     
	        try {
	        	
	        	//Create a new list of student to be filled by CSV file data 
	        	List<Patients> patientsList = new ArrayList<Patients>();
	        	
	            String line = "";
	            
	            //Create the file reader
	            reader = new BufferedReader(new FileReader(fileName));
	            
	            //Read the CSV file header to skip it at first itself
	            reader.readLine();
	            
	            //Read the file line by line starting from the second line
	            while ((line = reader.readLine()) != null) {
	                //Get all tokens available in line
	                String[] array_tokens = line.split(COMMA_DELIMITER);
	                if (array_tokens.length > 0) {
	                	//Create a new student object and fill his  data
						Patients pat = new Patients(array_tokens[0], array_tokens[1], array_tokens[2]);
						patientsList.add(pat);
					}
	            }
	            
	            //Print the new student list
	            String output = "";
	            for (Patients pat : patientsList) {
	            	  output += pat.toString();
				}
	            return output;
	            
				//return patData;
	        } 
	        catch (Exception e) {
	        	return e.getMessage();
	        } 

	    
	  }
		
	 @DELETE
	  public String deletePatient() {
		 BufferedReader reader = null;
	     
	        try {
	        	
	       
	        	//Create a new list of student to be filled by CSV file data 
	        	List<Patients> patientsList = new ArrayList<Patients>();
	        	
	            String line = "";
	            
	            //Create the file reader
	            reader = new BufferedReader(new FileReader(fileName));
	            
	            //Read the CSV file header to skip it
	            reader.readLine();
	            
	            //Read the file line by line starting from the second line
	            while ((line = reader.readLine()) != null) {
	            	
	                //Get all values available in line
	                String[] array_tokens = line.split(COMMA_DELIMITER);
	                if (array_tokens.length > 0) {
	                	
	                	//Create a new student object 
						Patients pat = new Patients(array_tokens[0], array_tokens[1], array_tokens[2]);
						if(!array_tokens[0].equals("1")){
							System.out.print(array_tokens[0]);
						patientsList.add(pat);
						}
					}
	            }
	            
	            //Print the new student list
	            String output = "sucess";
	            FileWriter file = null;
	         	file= new FileWriter(fileName);
			 
						file.append(FILE_HEADER.toString());
						//Add a new line separator after the header
						file.append(NEW_LINE_SEPARATOR);
				
				//Write a new student object list to the CSV file
				for (Patients pat : patientsList) {
					file.append(pat.getId());
					file.append(COMMA_DELIMITER);
					file.append(pat.getName());
					file.append(COMMA_DELIMITER);
					file.append(pat.getInsuranceNo());
					file.append(NEW_LINE_SEPARATOR);
				
				}
				file.flush();
				file.close();
				
	            return output;
	            
				//return patData;
	        } 
	        catch (Exception e) {
	        	return e.getMessage();
	        } 

		 
	 }
	 
	 
	


} 